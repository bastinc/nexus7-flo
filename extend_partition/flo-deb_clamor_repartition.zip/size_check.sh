#!/sbin/sh
#
# Copyright (C) 2018 Unlegacy Android Project
# Copyright (C) 2018 Svyatoslav Ryhel
#
# Made for Flo and Deb 16GB/32GB
#

parted /dev/block/mmcblk0 unit b p quit -> /tmp/part

touch /tmp/size.prop
if grep "28856794624B" /tmp/part > /dev/null
then
  echo "data.size=32G" >> /tmp/size.prop
  echo "data.type=original-H" >> /tmp/size.prop
else
  if grep "13342064128B" /tmp/part > /dev/null
  then
    echo "data.size=16G" >> /tmp/size.prop
    echo "data.type=original-T" >> /tmp/size.prop
  else
    if grep "28661726720B" /tmp/part > /dev/null
    then
      echo "data.size=32G" >> /tmp/size.prop
      echo "data.type=modified-H" >> /tmp/size.prop
    else
      if grep "13146996224B" /tmp/part > /dev/null
      then
        echo "data.size=16G" >> /tmp/size.prop
        echo "data.type=modified-T" >> /tmp/size.prop
      else
        if grep "28521250304B" /tmp/part > /dev/null
        then
          echo "data.size=32G" >> /tmp/size.prop
          echo "data.type=original-K" >> /tmp/size.prop
        else
          if grep "28326182400B" /tmp/part > /dev/null
          then
            echo "data.size=32G" >> /tmp/size.prop
            echo "data.type=modified-K" >> /tmp/size.prop
          else
            if grep "13052657152B" /tmp/part > /dev/null
            then
              echo "data.size=16G" >> /tmp/size.prop
              echo "data.type=original-K" >> /tmp/size.prop
            else
              if grep "12857589248B" /tmp/part > /dev/null
              then
                echo "data.size=16G" >> /tmp/size.prop
                echo "data.type=modified-K" >> /tmp/size.prop
              else
                if grep "13346258432B" /tmp/part > /dev/null
                then
                  echo "data.size=16G" >> /tmp/size.prop
                  echo "data.type=original-H" >> /tmp/size.prop
                else
                  if grep "13151190528B" /tmp/part > /dev/null
                  then
                    echo "data.size=16G" >> /tmp/size.prop
                    echo "data.type=modified-H" >> /tmp/size.prop
                  else
                    echo "data.size=unknown" >> /tmp/size.prop
                    echo "data.type=unknown" >> /tmp/size.prop
                  fi
                fi
              fi
            fi
          fi
        fi
      fi
    fi
  fi
fi

rm /tmp/part
